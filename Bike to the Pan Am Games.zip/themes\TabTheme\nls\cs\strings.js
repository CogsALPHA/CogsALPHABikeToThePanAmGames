﻿define(
   ({
    _themeLabel: "Rozvržení záložek",
    _layout_default: "Výchozí rozvržení",
    _layout_layout1: "Rozvržení 1"
  })
);
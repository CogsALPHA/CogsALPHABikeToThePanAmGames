﻿define(
   ({
    _widgetLabel: "Overskrift",
    signin: "Logg på",
    signout: "Logg ut",
    about: "Om",
    signInTo: "Logg inn på",
    cantSignOutTip: "Denne funksjonen er ikke relevant i forhåndsvisningsmodus."
  })
);

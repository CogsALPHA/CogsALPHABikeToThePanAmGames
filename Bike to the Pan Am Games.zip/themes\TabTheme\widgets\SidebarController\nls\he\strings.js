﻿define(
   ({
    _widgetLabel: "רצועת כלים צידית"
  })
);

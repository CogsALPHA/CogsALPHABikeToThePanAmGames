﻿define(
   ({
    _widgetLabel: "Controller bară laterală"
  })
);

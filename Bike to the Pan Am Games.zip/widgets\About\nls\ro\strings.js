﻿define(
   ({
    _widgetLabel: "Despre"
  })
);
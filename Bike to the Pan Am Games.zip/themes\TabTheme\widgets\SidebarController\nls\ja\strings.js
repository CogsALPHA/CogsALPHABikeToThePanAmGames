﻿define(
   ({
    _widgetLabel: "サイドバー構成"
  })
);

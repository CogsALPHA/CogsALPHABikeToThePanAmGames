﻿define(
   ({
    instruction: "Creaţi conţinut care va fi afişat în acest widget",
    defaultContent: "Adăugaţi aici text, legături şi alte imagini mici."
  })
);
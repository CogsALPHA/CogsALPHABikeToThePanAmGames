﻿define(
   ({
    _widgetLabel: "Sidefeltkontroller"
  })
);

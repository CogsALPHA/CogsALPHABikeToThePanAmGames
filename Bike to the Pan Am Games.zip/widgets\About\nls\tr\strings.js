﻿define(
   ({
    _widgetLabel: "Hakkında"
  })
);
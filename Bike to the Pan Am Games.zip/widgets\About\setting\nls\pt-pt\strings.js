﻿define(
   ({
    instruction: "Crie conteúdos que serão exibidos neste widget.",
    defaultContent: "Adicione texto, ligações e pequenos gráficos aqui."
  })
);
﻿define(
   ({
    _widgetLabel: "Gestionnaire d'interface"
  })
);

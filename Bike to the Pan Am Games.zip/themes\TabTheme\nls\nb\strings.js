﻿define(
   ({
    _themeLabel: "Temaet Fane",
    _layout_default: "Standard oppsett",
    _layout_layout1: "Oppsett 1"
  })
);
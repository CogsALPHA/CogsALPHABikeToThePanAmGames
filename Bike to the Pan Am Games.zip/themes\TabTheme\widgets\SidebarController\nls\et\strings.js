﻿define(
   ({
    _widgetLabel: "Külgriba kontroller"
  })
);

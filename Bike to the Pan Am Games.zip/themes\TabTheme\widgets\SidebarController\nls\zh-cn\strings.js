﻿define(
   ({
    _widgetLabel: "侧边栏控制器"
  })
);

﻿define(
   ({
    appCopyright: "All Rights Reserved",
    _widgetLabel: "ส่วนท้าย"
  })
);

﻿define(
   ({
    appCopyright: "All Rights Reserved",
    _widgetLabel: "Piè di pagina"
  })
);

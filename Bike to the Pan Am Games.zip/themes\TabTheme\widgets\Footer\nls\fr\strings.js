﻿define(
   ({
    appCopyright: "All Rights Reserved",
    _widgetLabel: "Pied de page"
  })
);

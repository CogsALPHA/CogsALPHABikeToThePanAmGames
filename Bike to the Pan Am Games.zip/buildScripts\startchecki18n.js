var checkScript = require('./checki18n');
checkScript.check();
﻿define(
   ({
    appCopyright: "All Rights Reserved",
    _widgetLabel: "Bundtekst"
  })
);

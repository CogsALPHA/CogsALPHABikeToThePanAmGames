﻿define(
   ({
    _widgetLabel: "사이드바 컨트롤러"
  })
);

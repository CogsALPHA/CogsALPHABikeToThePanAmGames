﻿define(
   ({
    _themeLabel: "Układ Karty",
    _layout_default: "Układ domyślny",
    _layout_layout1: "Układ 1"
  })
);
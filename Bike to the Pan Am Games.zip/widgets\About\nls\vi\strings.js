﻿define(
   ({
    _widgetLabel: "Về"
  })
);
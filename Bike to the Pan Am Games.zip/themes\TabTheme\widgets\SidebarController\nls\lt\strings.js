﻿define(
   ({
    _widgetLabel: "Šoninės juostos valdiklis"
  })
);

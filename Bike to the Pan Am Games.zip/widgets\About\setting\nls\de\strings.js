﻿define(
   ({
    instruction: "Erstellen Sie Inhalte, die in diesem Widget angezeigt werden sollen.",
    defaultContent: "Hier können Sie Text, Links und kleine Grafiken hinzufügen."
  })
);
﻿define(
   ({
    appCopyright: "All Rights Reserved",
    _widgetLabel: "Jalus"
  })
);

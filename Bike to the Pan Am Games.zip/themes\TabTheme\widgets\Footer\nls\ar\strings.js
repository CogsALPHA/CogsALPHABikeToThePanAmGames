﻿define(
   ({
    appCopyright: "All Rights Reserved",
    _widgetLabel: "أسفل الصفحة"
  })
);

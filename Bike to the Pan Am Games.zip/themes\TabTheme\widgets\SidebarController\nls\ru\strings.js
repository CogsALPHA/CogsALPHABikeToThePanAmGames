﻿define(
   ({
    _widgetLabel: "Контроллер боковой панели"
  })
);

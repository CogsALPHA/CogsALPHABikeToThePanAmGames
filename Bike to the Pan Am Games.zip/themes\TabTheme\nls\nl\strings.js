﻿define(
   ({
    _themeLabel: "Tabbladthema",
    _layout_default: "Standaard lay-out",
    _layout_layout1: "Lay-out 1"
  })
);
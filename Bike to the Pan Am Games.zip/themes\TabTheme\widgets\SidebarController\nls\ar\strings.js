﻿define(
   ({
    _widgetLabel: "وحدة تحكم الشريط الجانبي"
  })
);

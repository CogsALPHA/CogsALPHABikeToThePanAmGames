﻿define(
   ({
    instruction: "이 위젯에 표시될 콘텐츠를 만듭니다.",
    defaultContent: "텍스트, 링크 및 작은 그래픽을 여기에 추가합니다."
  })
);
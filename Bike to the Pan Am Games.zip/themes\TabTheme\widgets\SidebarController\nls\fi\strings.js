﻿define(
   ({
    _widgetLabel: "Sivupalkki-säädin"
  })
);

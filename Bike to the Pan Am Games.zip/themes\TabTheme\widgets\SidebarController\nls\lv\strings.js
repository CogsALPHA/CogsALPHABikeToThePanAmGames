﻿define(
   ({
    _widgetLabel: "Sānu joslas kontrolieris"
  })
);

﻿define(
   ({
    _widgetLabel: "Koptekst",
    signin: "Aanmelden",
    signout: "Afmelden",
    about: "Over",
    signInTo: "Meld u aan bij",
    cantSignOutTip: "Deze functie is niet beschikbaar in de voorbeeldmodus."
  })
);

﻿define(
   ({
    instruction: "Skapa innehåll som ska visas i widgeten.",
    defaultContent: "Lägg till texter, länkar och små bilder här."
  })
);
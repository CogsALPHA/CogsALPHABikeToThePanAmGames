﻿define(
   ({
    _widgetLabel: "Tietoja"
  })
);
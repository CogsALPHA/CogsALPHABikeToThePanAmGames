﻿define(
   ({
    _widgetLabel: "אודות"
  })
);
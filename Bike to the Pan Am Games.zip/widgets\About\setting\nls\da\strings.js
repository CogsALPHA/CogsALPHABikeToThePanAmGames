﻿define(
   ({
    instruction: "Opret indhold, der skal vises i denne widget.",
    defaultContent: "Tilføj tekst, links og små billeder her."
  })
);
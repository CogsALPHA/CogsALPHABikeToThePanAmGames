﻿define(
   ({
    _themeLabel: "Temă cu file",
    _layout_default: "Configuraţie implicită",
    _layout_layout1: "Aspectul 1"
  })
);
﻿define(
   ({
    appCopyright: "All Rights Reserved",
    _widgetLabel: "바닥글"
  })
);

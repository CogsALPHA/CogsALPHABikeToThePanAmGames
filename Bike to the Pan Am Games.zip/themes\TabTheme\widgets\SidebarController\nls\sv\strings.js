﻿define(
   ({
    _widgetLabel: "Sidopanelskontroll"
  })
);

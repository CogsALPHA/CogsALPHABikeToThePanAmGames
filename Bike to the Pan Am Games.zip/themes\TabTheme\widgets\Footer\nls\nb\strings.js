﻿define(
   ({
    appCopyright: "All Rights Reserved",
    _widgetLabel: "Bunntekst"
  })
);

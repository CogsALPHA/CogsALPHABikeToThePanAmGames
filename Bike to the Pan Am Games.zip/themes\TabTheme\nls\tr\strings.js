﻿define(
   ({
    _themeLabel: "Sekme Teması",
    _layout_default: "Varsayılan Düzen",
    _layout_layout1: "Düzen 1"
  })
);
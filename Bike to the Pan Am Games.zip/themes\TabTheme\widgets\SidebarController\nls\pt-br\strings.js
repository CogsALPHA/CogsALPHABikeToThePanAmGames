﻿define(
   ({
    _widgetLabel: "Controlador da Barra Lateral"
  })
);

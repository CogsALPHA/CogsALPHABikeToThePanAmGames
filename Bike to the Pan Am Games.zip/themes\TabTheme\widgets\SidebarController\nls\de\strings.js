﻿define(
   ({
    _widgetLabel: "Sidebar-Controller"
  })
);

﻿define(
   ({
    _widgetLabel: "Ovladač postranního panelu"
  })
);

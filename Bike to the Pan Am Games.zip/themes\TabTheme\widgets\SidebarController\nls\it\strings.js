﻿define(
   ({
    _widgetLabel: "Controller barra laterale"
  })
);

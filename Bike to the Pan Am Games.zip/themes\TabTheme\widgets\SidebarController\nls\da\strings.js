﻿define(
   ({
    _widgetLabel: "Margentekst-controller"
  })
);

﻿define(
   ({
    _widgetLabel: "Controller van zijbalk"
  })
);

﻿define(
   ({
    _widgetLabel: "О"
  })
);
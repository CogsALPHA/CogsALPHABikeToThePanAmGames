﻿define(
   ({
    appCopyright: "All Rights Reserved",
    _widgetLabel: "Cuối trang"
  })
);

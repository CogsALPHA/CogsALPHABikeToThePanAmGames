﻿define(
   ({
    instruction: "Content maken die wordt weergegeven in deze widget.",
    defaultContent: "Voeg hier tekst, koppelingen en kleine afbeeldingen toe."
  })
);
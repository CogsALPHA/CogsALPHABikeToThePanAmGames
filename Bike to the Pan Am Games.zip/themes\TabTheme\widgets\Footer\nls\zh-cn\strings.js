﻿define(
   ({
    appCopyright: "All Rights Reserved",
    _widgetLabel: "页脚"
  })
);

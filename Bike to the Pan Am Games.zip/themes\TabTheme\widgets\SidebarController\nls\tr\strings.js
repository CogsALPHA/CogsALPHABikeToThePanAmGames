﻿define(
   ({
    _widgetLabel: "Kenar Çubuğu Denetleyicisi"
  })
);

﻿define(
   ({
    _widgetLabel: "Ylätunniste",
    signin: "Kirjaudu sisään",
    signout: "Kirjaudu ulos",
    about: "Tietoja",
    signInTo: "Kirjaudu palveluun",
    cantSignOutTip: "Toiminto ei ole käytettävissä esikatselutilassa."
  })
);

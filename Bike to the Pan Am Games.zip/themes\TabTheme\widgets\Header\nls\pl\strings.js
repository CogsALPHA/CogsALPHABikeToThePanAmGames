﻿define(
   ({
    _widgetLabel: "Nagłówek",
    signin: "Zaloguj się",
    signout: "Wyloguj się",
    about: "Informacje o",
    signInTo: "Zaloguj się do",
    cantSignOutTip: "Funkcja nie ma zastosowania w widoku podglądu."
  })
);

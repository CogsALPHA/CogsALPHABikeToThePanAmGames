﻿define(
   ({
    _widgetLabel: "ตัวควบคุมแถบด้านข้าง"
  })
);

﻿define(
   ({
    _widgetLabel: "Info"
  })
);
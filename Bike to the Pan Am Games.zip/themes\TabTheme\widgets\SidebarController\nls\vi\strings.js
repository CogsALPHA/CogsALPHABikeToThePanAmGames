﻿define(
   ({
    _widgetLabel: "Trình điều khiển Thanh bên"
  })
);

﻿define(
   ({
    _widgetLabel: "Kontroler paska bocznego"
  })
);
